import streamlit as st
import pickle

# Load models
model = {
    "diabetes": pickle.load(open('diabetes_model.sav', 'rb')),
    "heart": pickle.load(open('heart_disease_model (1).sav', 'rb')),
    "lungs": pickle.load(open('lungs_disease_model.sav', 'rb')),
    "parkinsons": pickle.load(open('parkinsons_model.sav', 'rb')),
    "thyroid": pickle.load(open('Thyroid_model.sav', 'rb'))
}

# Optional: Map thyroid predictions to user-friendly messages
label_map = {
    "thyroid": {
        "hypothyroid": "You may have hypothyroidism.",
        "negative": "Thyroid function appears normal.",
        "sick": "Signs of thyroid-related illness detected.",
        "primary_hypothyroid": "Primary hypothyroidism detected.",
        "compensated_hypothyroid": "Compensated hypothyroidism detected."
    }
}

# Input helper
def display_input(label, tooltip, key, type):
    if type == 'text':
        return st.text_input(label, key=key, help=tooltip)
    elif type == 'number':
        return st.number_input(label, key=key, help=tooltip)

# Prediction helper
def predict_disease(model_key, input_data, label):
    try:
        prediction = model[model_key].predict([input_data])
        result = prediction[0]

        # Handle thyroid string outputs
        if model_key == "thyroid":
            mapped = label_map["thyroid"].get(result, f"Prediction result: {result}")
            st.success(mapped)
        else:
            # Binary classification fallback
            if result == 1:
                st.success(f"Likely to have {label}")
            else:
                st.success(f"Not likely to have {label}")
    except Exception as e:
        st.error(f"Prediction failed: {e}")

# Disease selection
selectbox = st.selectbox(
    'Select disease to predict',
    [
        'Diabetes Prediction',
        'Heart Disease Prediction',
        'Lungs Disease Prediction',
        'Parkinsons Prediction',
        'Thyroid prediction'
    ]
)

# Diabetes
if selectbox == 'Diabetes Prediction':
    st.title("Diabetes Prediction")
    st.write("Enter the Details below")

    input_data = [
        display_input("Pregnancies", "Number of times pregnant", "Pregnancies", "number"),
        display_input("Glucose", "Plasma glucose concentration", "Glucose", "number"),
        display_input("Blood Pressure", "Diastolic blood pressure (mm Hg)", "BloodPressure", "number"),
        display_input("Skin Thickness", "Triceps skin fold thickness (mm)", "SkinThickness", "number"),
        display_input("Insulin", "2-Hour serum insulin (mu U/ml)", "Insulin", "number"),
        display_input("BMI", "Body mass index", "BMI", "number"),
        display_input("Diabetes Pedigree Function", "Diabetes pedigree function", "DPF", "number"),
        display_input("Age", "Age in years", "Age", "number")
    ]

    if st.button("Predict Diabetes"):
        predict_disease("diabetes", input_data, "Diabetes")

# Heart
elif selectbox == 'Heart Disease Prediction':
    st.title("Heart Disease Prediction")
    st.write("Enter the Details below")

    input_data = [
        display_input("Age", "Age in years", "Age_heart", "number"),
        display_input("Sex", "0 = Female, 1 = Male", "Sex", "number"),
        display_input("Chest Pain Type", "0–3", "ChestPain", "number"),
        display_input("Resting BP", "Resting blood pressure", "RestBP", "number"),
        display_input("Cholesterol", "Serum cholesterol", "Cholesterol", "number"),
        display_input("Fasting Blood Sugar", "1 if > 120 mg/dl", "FBS", "number"),
        display_input("Resting ECG", "0–2", "RestECG", "number"),
        display_input("Max Heart Rate", "Maximum heart rate achieved", "MaxHR", "number"),
        display_input("Exercise Induced Angina", "0 or 1", "ExAng", "number"),
        display_input("Oldpeak", "ST depression", "Oldpeak", "number"),
        display_input("Slope", "Slope of peak exercise ST segment", "Slope", "number"),
        display_input("CA", "Number of major vessels (0–3)", "CA", "number"),
        display_input("Thal", "Thalassemia (0–3)", "Thal", "number")
    ]

    if st.button("Predict Heart Disease"):
        predict_disease("heart", input_data, "Heart Disease")

# Lungs
elif selectbox == 'Lungs Disease Prediction':
    st.title("Parkinson's Disease Prediction")
    st.write("Enter the voice measurements below:")

    input_data = [
    display_input("Gender", "0 = Female, 1 = Male", "Gender", "number"),
    display_input("Age", "Age in years", "Age_lungs", "number"),
    display_input("Smoking", "0 = No, 1 = Yes", "Smoking", "number"),
    display_input("Yellow Fingers", "0–2 scale", "YellowFingers", "number"),
    display_input("Anxiety", "0–2 scale", "Anxiety", "number"),
    display_input("Peer Pressure", "0–2 scale", "PeerPressure", "number"),
    display_input("Chronic Disease", "0 = No, 1 = Yes", "ChronicDisease", "number"),
    display_input("Fatigue", "0–2 scale", "Fatigue", "number"),
    display_input("Allergy", "0 = No, 1 = Yes", "Allergy", "number"),
    display_input("Wheezing", "0–2 scale", "Wheezing", "number"),
    display_input("Alcohol Consumption", "0–2 scale", "Alcohol", "number"),
    display_input("Coughing", "0–2 scale", "Coughing", "number"),
    display_input("Shortness of Breath", "0–2 scale", "Breath", "number"),
    display_input("Swallowing Difficulty", "0–2 scale", "Swallowing", "number"),
    display_input("Chest Pain", "0–2 scale", "ChestPain_lungs", "number")
]
    if st.button("Predict Lungs Disease"):
        predict_disease("lungs", input_data, "Lungs Disease")


# Parkinsons
elif selectbox == 'Parkinsons Prediction':
    st.title("Parkinson's Disease Prediction")
    st.write("Enter the voice measurements below:")

    input_data = [
        st.number_input("MDVP:Fo(Hz)"),
        st.number_input("MDVP:Fhi(Hz)"),
        st.number_input("MDVP:Flo(Hz)"),
        st.number_input("MDVP:Jitter(%)"),
        st.number_input("MDVP:Jitter(Abs)"),
        st.number_input("MDVP:RAP"),
        st.number_input("MDVP:PPQ"),
        st.number_input("Jitter:DDP"),
        st.number_input("MDVP:Shimmer"),
        st.number_input("MDVP:Shimmer(dB)"),
        st.number_input("Shimmer:APQ3"),
        st.number_input("Shimmer:APQ5"),
        st.number_input("MDVP:APQ"),
        st.number_input("Shimmer:DDA"),
        st.number_input("NHR"),
        st.number_input("HNR"),
        st.number_input("RPDE"),
        st.number_input("DFA"),
        st.number_input("spread1"),
        st.number_input("spread2"),
        st.number_input("D2"),
        st.number_input("PPE")
    ]

    if st.button("Predict Parkinson's"):
        predict_disease("parkinsons", input_data, "Parkinson's")

# Thyroid
elif selectbox == 'Thyroid prediction':
    st.title("Thyroid Prediction")
    st.write("Enter the Details below")

    input_data = [
        st.number_input("Age"),
        st.selectbox("Sex", ["F", "M"]),
        st.selectbox("On Thyroxine", ["t", "f"]),
        st.selectbox("Query on Thyroxine", ["t", "f"]),
        st.selectbox("On Antithyroid Medication", ["t", "f"]),
        st.selectbox("Sick", ["t", "f"]),
        st.selectbox("Pregnant", ["t", "f"]),
        st.selectbox("Thyroid Surgery", ["t", "f"]),
        st.selectbox("I131 Treatment", ["t", "f"]),
        st.selectbox("Query Hypothyroid", ["t", "f"]),
        st.selectbox("Lithium", ["t", "f"]),
        st.selectbox("Goitre", ["t", "f"]),
        st.selectbox("Tumor", ["t", "f"]),
        st.selectbox("Hypopituitary", ["t", "f"]),
        st.selectbox("Psych", ["t", "f"]),
        st.selectbox("TSH Measured", ["t", "f"]),
        st.number_input("TSH"),
        st.selectbox("T3 Measured", ["t", "f"]),
        st.number_input("T3"),
        st.selectbox("TT4 Measured", ["t", "f"]),
        st.number_input("TT4"),
        st.selectbox("T4U Measured", ["t", "f"]),
        st.number_input("T4U"),
        st.selectbox("FTI Measured", ["t", "f"]),
        st.number_input("FTI"),
        st.selectbox("TBG Measured", ["t", "f"]),
        st.number_input("TBG"),
        st.selectbox("Referral Source", ["SVHC", "STMW", "SVI", "SVHD", "other"])
    ]

    if st.button("Predict Thyroid"):
        predict_disease("thyroid", input_data, "Thyroid")